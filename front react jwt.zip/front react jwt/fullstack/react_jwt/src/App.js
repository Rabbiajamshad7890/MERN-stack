import React from 'react'
import Button from 'react-bootstrap/Button';
import Signup from './comp/signup/signup';
import Login from './comp/login/login';
import Dashbaord from './comp/dashboard/dashbaord';
import { Routes, Route } from 'react-router-dom';
import Header from './comp/header/Header';

function App() {
  return (
    <div>
      <Button variant="primary">Primary</Button>
   <Header/>
      <Routes>

<Route path="/login" element={<Login/>} />
<Route path="/register" element={<Signup/>} />
<Route path="/dashboard" element={<Dashbaord/>} />


      </Routes>
    </div>
  )
}

export default App