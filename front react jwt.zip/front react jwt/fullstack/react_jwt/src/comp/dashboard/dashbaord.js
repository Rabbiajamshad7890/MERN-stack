import React from 'react'

function Dashbaord() {
  return (
    <div>
  welcome to dashboard


    </div>
  )
}

export default Dashbaord